import json
import boto3
import os
import logging

#setpu logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

#initalize clients
client = boto3.client('codecommit')
sns_topic = os.environ['SNSTopic']
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    
    #parse event
    event_body = json.loads(event["Records"][0]["body"])
    logger.info(event_body)
    
    #check if event was a creation
    if "Created" in event_body["detail"]["notificationBody"]:
        
        #parse event
        event_name = event_body["detail"]["event"]
        repo_name = event_body["detail"]["repositoryNames"][0]
        author_name = event_body["detail"]["author"]
        pr_id = event_body["detail"]["pullRequestId"]
        
        #pull info about request
        response = client.describe_pull_request_events(pullRequestId=pr_id)
        
        #create SNS message with API gateway link to approve
        api = os.environ['APIUrl'] + pr_id + "&repo_id=" + repo_name
        message = "A Pull Request has been created by {} on repository {}.\n\n Please visit the following link to approve:\n{}".format(author_name, repo_name, api)
        
        #publish message to topic
        response = sns_client.publish(TopicArn=sns_topic, Message=message)
        logger.info(response)
        
        return {
            'statusCode': 200,
            'body': json.dumps("Success")
            
        }
    else:
        print("Not a creation event")
        response = {"Status": "Not a creation event"}
        return {
             'statusCode': 200,
             'body': json.dumps(response)
         }

        
       
