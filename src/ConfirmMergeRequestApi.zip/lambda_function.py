import json
import boto3
import os
import logging

#setpu logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

#initalize clients
client = boto3.client('codecommit')

def lambda_handler(event, context):
    
    #parse event, which should be an API GET Request
    pr_id = event["queryStringParameters"]["pr_id"]
    repo_name = event["queryStringParameters"]["repo_id"]
    logger.info("Pull Request ID: {}, Repo Name: {}".format(pr_id, repo_name))
    
    #Merge the request
    try:
        response = client.merge_pull_request_by_fast_forward(pullRequestId=pr_id, repositoryName=repo_name)
        logger.info(response)
        ret_body={"status": "Success", "pr_id": pr_id, "repo_name": repo_name }
    except Exception as e:
        logger.info("Except: {}".format(e))
        ret_body={"status": "Failed", "Exception": str(e) }
    
    return {
        'statusCode': 200,
        'isBase64Encoded': "false",
        'headers': {},
        'multiValueHeaders': {},
        'body': json.dumps(ret_body)
    }
